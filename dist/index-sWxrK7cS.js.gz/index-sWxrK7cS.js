import { S as H, a as W, b as k, E as j, P as N, T as K, V as p } from "./index-BF77lfCT.js";
import { v as P, b as d } from "./v4-Duvinf9q.js";
function T(r) {
  return r.version === void 0;
}
function E(r) {
  return T(r) ? r.serialize({
    verifySignatures: !1,
    requireAllSignatures: !1
  }) : r.serialize();
}
var x = function(r, n, e, t) {
  function i(s) {
    return s instanceof e ? s : new e(function(a) {
      a(s);
    });
  }
  return new (e || (e = Promise))(function(s, a) {
    function u(o) {
      try {
        l(t.next(o));
      } catch (h) {
        a(h);
      }
    }
    function m(o) {
      try {
        l(t.throw(o));
      } catch (h) {
        a(h);
      }
    }
    function l(o) {
      o.done ? s(o.value) : i(o.value).then(u, m);
    }
    l((t = t.apply(r, n || [])).next());
  });
};
function A(r) {
  return x(this, void 0, void 0, function* () {
    try {
      return yield r.request({ method: "wallet_getSnaps" }), !0;
    } catch {
      return !1;
    }
  });
}
function F() {
  return x(this, void 0, void 0, function* () {
    try {
      const r = window.ethereum;
      if (!r)
        return null;
      if (r.providers && Array.isArray(r.providers)) {
        const n = r.providers;
        for (const e of n)
          if (yield A(e))
            return e;
      }
      if (r.detected && Array.isArray(r.detected)) {
        const n = r.detected;
        for (const e of n)
          if (yield A(e))
            return e;
      }
      return (yield A(r)) ? r : null;
    } catch (r) {
      return console.error(r), null;
    }
  });
}
const O = "solana:mainnet", L = "solana:devnet", $ = "solana:testnet", R = "solana:localnet", z = [
  O,
  L,
  $,
  R
];
function M(r) {
  return z.includes(r);
}
var f = function(r, n, e, t) {
  if (e === "a" && !t) throw new TypeError("Private accessor was defined without a getter");
  if (typeof n == "function" ? r !== n || !t : !n.has(r)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return e === "m" ? t : e === "a" ? t.call(r) : t ? t.value : n.get(r);
}, _ = function(r, n, e, t, i) {
  if (t === "m") throw new TypeError("Private method is not writable");
  if (t === "a" && !i) throw new TypeError("Private accessor was defined without a setter");
  if (typeof n == "function" ? r !== n || !i : !n.has(r)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return t === "a" ? i.call(r, e) : i ? i.value = e : n.set(r, e), e;
}, v, g, w, y, b, S;
const D = z, U = [H, W, k];
class C {
  get address() {
    return f(this, v, "f");
  }
  get publicKey() {
    return f(this, g, "f").slice();
  }
  get chains() {
    return f(this, w, "f").slice();
  }
  get features() {
    return f(this, y, "f").slice();
  }
  get label() {
    return f(this, b, "f");
  }
  get icon() {
    return f(this, S, "f");
  }
  constructor({ address: n, publicKey: e, label: t, icon: i }) {
    v.set(this, void 0), g.set(this, void 0), w.set(this, void 0), y.set(this, void 0), b.set(this, void 0), S.set(this, void 0), new.target === C && Object.freeze(this), _(this, v, n, "f"), _(this, g, e, "f"), _(this, w, D, "f"), _(this, y, U, "f"), _(this, b, t, "f"), _(this, S, i, "f");
  }
}
v = /* @__PURE__ */ new WeakMap(), g = /* @__PURE__ */ new WeakMap(), w = /* @__PURE__ */ new WeakMap(), y = /* @__PURE__ */ new WeakMap(), b = /* @__PURE__ */ new WeakMap(), S = /* @__PURE__ */ new WeakMap();
var c = function(r, n, e, t) {
  function i(s) {
    return s instanceof e ? s : new e(function(a) {
      a(s);
    });
  }
  return new (e || (e = Promise))(function(s, a) {
    function u(o) {
      try {
        l(t.next(o));
      } catch (h) {
        a(h);
      }
    }
    function m(o) {
      try {
        l(t.throw(o));
      } catch (h) {
        a(h);
      }
    }
    function l(o) {
      o.done ? s(o.value) : i(o.value).then(u, m);
    }
    l((t = t.apply(r, n || [])).next());
  });
};
class I extends j {
  constructor(n) {
    super(), this._network = "mainnet-beta", this._iframeParams = {}, this._element = null, this._iframe = null, this._publicKey = null, this._account = null, this._isConnected = !1, this._connectHandler = null, this._messageHandlers = {}, this._handleEvent = (e) => {
      var t, i;
      switch (e.type) {
        case "connect": {
          this._collapseIframe(), !((t = e.data) === null || t === void 0) && t.publicKey ? (this._publicKey = e.data.publicKey, this._isConnected = !0, this._connectHandler && (this._connectHandler.resolve(), this._connectHandler = null), this._connected()) : (this._connectHandler && (this._connectHandler.reject(), this._connectHandler = null), this._disconnected());
          return;
        }
        case "disconnect": {
          this._connectHandler && (this._connectHandler.reject(), this._connectHandler = null), this._disconnected();
          return;
        }
        case "accountChanged": {
          !((i = e.data) === null || i === void 0) && i.publicKey ? (this._publicKey = e.data.publicKey, this.emit("accountChanged", this.publicKey), this._standardConnected()) : (this.emit("accountChanged", void 0), this._standardDisconnected());
          return;
        }
        default:
          return;
      }
    }, this._handleResize = (e) => {
      e.resizeMode === "full" ? e.params.mode === "fullscreen" ? this._expandIframe() : e.params.mode === "hide" && this._collapseIframe() : e.resizeMode === "coordinates" && this._resizeIframe(e.params);
    }, this._handleMessage = (e) => {
      var t;
      if (((t = e.data) === null || t === void 0 ? void 0 : t.channel) !== "solflareIframeToWalletAdapter")
        return;
      const i = e.data.data || {};
      if (i.type === "event")
        this._handleEvent(i.event);
      else if (i.type === "resize")
        this._handleResize(i);
      else if (i.type === "response" && this._messageHandlers[i.id]) {
        const { resolve: s, reject: a } = this._messageHandlers[i.id];
        delete this._messageHandlers[i.id], i.error ? a(i.error) : s(i.result);
      }
    }, this._removeElement = () => {
      this._element && (this._element.remove(), this._element = null);
    }, this._removeDanglingElements = () => {
      const e = document.getElementsByClassName("solflare-metamask-wallet-adapter-iframe");
      for (const t of e)
        t.parentElement && t.remove();
    }, this._injectElement = () => {
      this._removeElement(), this._removeDanglingElements();
      const e = Object.assign(Object.assign({}, this._iframeParams), { mm: !0, v: 1, cluster: this._network || "mainnet-beta", origin: window.location.origin || "", title: document.title || "" }), t = Object.keys(e).map((s) => `${s}=${encodeURIComponent(e[s])}`).join("&"), i = `${I.IFRAME_URL}?${t}`;
      this._element = document.createElement("div"), this._element.className = "solflare-metamask-wallet-adapter-iframe", this._element.innerHTML = `
      <iframe src='${i}' style='position: fixed; top: 0; bottom: 0; left: 0; right: 0; width: 100%; height: 100%; border: none; border-radius: 0; z-index: 99999; color-scheme: auto;' allowtransparency='true'></iframe>
    `, document.body.appendChild(this._element), this._iframe = this._element.querySelector("iframe"), window.addEventListener("message", this._handleMessage, !1);
    }, this._collapseIframe = () => {
      this._iframe && (this._iframe.style.top = "", this._iframe.style.right = "", this._iframe.style.height = "2px", this._iframe.style.width = "2px");
    }, this._expandIframe = () => {
      this._iframe && (this._iframe.style.top = "0px", this._iframe.style.bottom = "0px", this._iframe.style.left = "0px", this._iframe.style.right = "0px", this._iframe.style.width = "100%", this._iframe.style.height = "100%");
    }, this._resizeIframe = (e) => {
      this._iframe && (this._iframe.style.top = isFinite(e.top) ? `${e.top}px` : "", this._iframe.style.bottom = isFinite(e.bottom) ? `${e.bottom}px` : "", this._iframe.style.left = isFinite(e.left) ? `${e.left}px` : "", this._iframe.style.right = isFinite(e.right) ? `${e.right}px` : "", this._iframe.style.width = isFinite(e.width) ? `${e.width}px` : e.width, this._iframe.style.height = isFinite(e.height) ? `${e.height}px` : e.height);
    }, this._sendIframeMessage = (e) => {
      if (!this.connected || !this.publicKey)
        throw new Error("Wallet not connected");
      return new Promise((t, i) => {
        var s, a;
        const u = P();
        this._messageHandlers[u] = { resolve: t, reject: i }, (a = (s = this._iframe) === null || s === void 0 ? void 0 : s.contentWindow) === null || a === void 0 || a.postMessage({
          channel: "solflareWalletAdapterToIframe",
          data: Object.assign({ id: u }, e)
        }, "*");
      });
    }, this._connected = () => {
      this._isConnected = !0, this.emit("connect", this.publicKey), this._standardConnected();
    }, this._disconnected = () => {
      this._publicKey = null, this._isConnected = !1, window.removeEventListener("message", this._handleMessage, !1), this._removeElement(), this.emit("disconnect"), this._standardDisconnected();
    }, this._standardConnected = () => {
      if (!this.publicKey)
        return;
      const e = this.publicKey.toString();
      (!this._account || this._account.address !== e) && (this._account = new C({
        address: e,
        publicKey: this.publicKey.toBytes()
      }), this.emit("standard_change", { accounts: this.standardAccounts }));
    }, this._standardDisconnected = () => {
      this._account && (this._account = null, this.emit("standard_change", { accounts: this.standardAccounts }));
    }, n?.network && (this._network = n?.network), window.SolflareMetaMaskParams && (this._iframeParams = Object.assign(Object.assign({}, this._iframeParams), window.SolflareMetaMaskParams)), n?.params && (this._iframeParams = Object.assign(Object.assign({}, this._iframeParams), n?.params));
  }
  get publicKey() {
    return this._publicKey ? new N(this._publicKey) : null;
  }
  get standardAccount() {
    return this._account;
  }
  get standardAccounts() {
    return this._account ? [this._account] : [];
  }
  get isConnected() {
    return this._isConnected;
  }
  get connected() {
    return this.isConnected;
  }
  get autoApprove() {
    return !1;
  }
  connect() {
    return c(this, void 0, void 0, function* () {
      this.connected || (this._injectElement(), yield new Promise((n, e) => {
        this._connectHandler = { resolve: n, reject: e };
      }));
    });
  }
  disconnect() {
    return c(this, void 0, void 0, function* () {
      yield this._sendIframeMessage({
        method: "disconnect"
      }), this._disconnected();
    });
  }
  signTransaction(n) {
    var e;
    return c(this, void 0, void 0, function* () {
      if (!this.connected || !this.publicKey)
        throw new Error("Wallet not connected");
      try {
        const t = E(n), i = yield this._sendIframeMessage({
          method: "signTransactionV2",
          params: {
            transaction: d.encode(t)
          }
        }), { transaction: s } = i;
        return T(n) ? K.from(d.decode(s)) : p.deserialize(d.decode(s));
      } catch (t) {
        throw new Error(((e = t?.toString) === null || e === void 0 ? void 0 : e.call(t)) || "Failed to sign transaction");
      }
    });
  }
  signAllTransactions(n) {
    var e;
    return c(this, void 0, void 0, function* () {
      if (!this.connected || !this.publicKey)
        throw new Error("Wallet not connected");
      try {
        const t = n.map((s) => E(s)), { transactions: i } = yield this._sendIframeMessage({
          method: "signAllTransactionsV2",
          params: {
            transactions: t.map((s) => d.encode(s))
          }
        });
        return i.map((s, a) => T(n[a]) ? K.from(d.decode(s)) : p.deserialize(d.decode(s)));
      } catch (t) {
        throw new Error(((e = t?.toString) === null || e === void 0 ? void 0 : e.call(t)) || "Failed to sign transactions");
      }
    });
  }
  signAndSendTransaction(n, e) {
    var t;
    return c(this, void 0, void 0, function* () {
      if (!this.connected || !this.publicKey)
        throw new Error("Wallet not connected");
      try {
        const i = E(n), { signature: s } = yield this._sendIframeMessage({
          method: "signAndSendTransaction",
          params: {
            transaction: d.encode(i),
            options: e
          }
        });
        return s;
      } catch (i) {
        throw new Error(((t = i?.toString) === null || t === void 0 ? void 0 : t.call(i)) || "Failed to sign and send transaction");
      }
    });
  }
  signMessage(n, e = "utf8") {
    var t;
    return c(this, void 0, void 0, function* () {
      if (!this.connected || !this.publicKey)
        throw new Error("Wallet not connected");
      try {
        const { signature: i } = yield this._sendIframeMessage({
          method: "signMessage",
          params: {
            data: d.encode(n),
            display: e
          }
        });
        return Uint8Array.from(d.decode(i));
      } catch (i) {
        throw new Error(((t = i?.toString) === null || t === void 0 ? void 0 : t.call(i)) || "Failed to sign message");
      }
    });
  }
  sign(n, e = "utf8") {
    return c(this, void 0, void 0, function* () {
      return yield this.signMessage(n, e);
    });
  }
  static isSupported() {
    return c(this, void 0, void 0, function* () {
      return !!(yield F());
    });
  }
  standardSignAndSendTransaction(...n) {
    return c(this, void 0, void 0, function* () {
      if (!this.connected)
        throw new Error("not connected");
      const e = [];
      if (n.length === 1) {
        const { transaction: t, account: i, chain: s, options: a } = n[0], { minContextSlot: u, preflightCommitment: m, skipPreflight: l, maxRetries: o } = a || {};
        if (i !== this._account)
          throw new Error("invalid account");
        if (!M(s))
          throw new Error("invalid chain");
        const h = yield this.signAndSendTransaction(p.deserialize(t), {
          preflightCommitment: m,
          minContextSlot: u,
          maxRetries: o,
          skipPreflight: l
        });
        e.push({ signature: d.decode(h) });
      } else if (n.length > 1)
        for (const t of n)
          e.push(...yield this.standardSignAndSendTransaction(t));
      return e;
    });
  }
  standardSignTransaction(...n) {
    return c(this, void 0, void 0, function* () {
      if (!this.connected)
        throw new Error("not connected");
      const e = [];
      if (n.length === 1) {
        const { transaction: t, account: i, chain: s } = n[0];
        if (i !== this._account)
          throw new Error("invalid account");
        if (s && !M(s))
          throw new Error("invalid chain");
        const a = yield this.signTransaction(p.deserialize(t));
        e.push({ signedTransaction: a.serialize() });
      } else if (n.length > 1) {
        let t;
        for (const a of n) {
          if (a.account !== this._account)
            throw new Error("invalid account");
          if (a.chain) {
            if (!M(a.chain))
              throw new Error("invalid chain");
            if (t) {
              if (a.chain !== t)
                throw new Error("conflicting chain");
            } else
              t = a.chain;
          }
        }
        const i = n.map(({ transaction: a }) => p.deserialize(a)), s = yield this.signAllTransactions(i);
        e.push(...s.map((a) => ({
          signedTransaction: a.serialize()
        })));
      }
      return e;
    });
  }
  standardSignMessage(...n) {
    return c(this, void 0, void 0, function* () {
      if (!this.connected)
        throw new Error("not connected");
      const e = [];
      if (n.length === 1) {
        const { message: t, account: i } = n[0];
        if (i !== this._account)
          throw new Error("invalid account");
        const s = yield this.signMessage(t);
        e.push({ signedMessage: t, signature: s });
      } else if (n.length > 1)
        for (const t of n)
          e.push(...yield this.standardSignMessage(t));
      return e;
    });
  }
}
I.IFRAME_URL = "https://widget.solflare.com/";
export {
  C as StandardSolflareMetaMaskWalletAccount,
  I as default
};
//# sourceMappingURL=index-sWxrK7cS.js.map
